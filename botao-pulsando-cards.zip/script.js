window.tsParticles.load('tsparticles', {
  background: { color: { value: '#f9fafb' } },
  particles: {
    color: { value: '#111827' },
    links: {
      enable: true,
      distance: 120,
      color: '#111827',
      opacity: 0.3,
      width: 1
    },
    move: {
      enable: true,
      speed: 1,
      outModes: { default: 'bounce' }
    },
    number: {
      value: 60,
      density: { enable: true, area: 800 }
    },
    opacity: { value: 0.6 },
    shape: { type: 'circle' },
    size: { value: { min: 1, max: 4 } }
  },
  detectRetina: true
});
